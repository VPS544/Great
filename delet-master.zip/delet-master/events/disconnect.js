module.exports = client => {
    console.log(`Disconnected at ${new Date()}.`);
};