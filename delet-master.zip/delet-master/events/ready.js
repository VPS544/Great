const chalk = require('chalk');
module.exports = client => {
    console.log(chalk.bgGreen('I\'m online.\nI\'m online.'));
};